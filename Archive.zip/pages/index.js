import Hero from "@/components/Hero";
import AppNav from "@/components/AppNav";
import Content from "@/components/Content";


export default function Home() {
  return (
    <>
      <AppNav />
      <Hero />
      <Content />
    </>
  )
}
